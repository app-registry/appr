# Elasticsearch

This Chart provides a basic Elasticsearch search service.
