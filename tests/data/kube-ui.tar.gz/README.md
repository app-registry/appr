
kube-ui
===========

# Install

kpm deploy kube-ui
